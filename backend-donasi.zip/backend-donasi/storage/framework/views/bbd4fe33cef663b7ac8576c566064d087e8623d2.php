<?php $__env->startSection('content'); ?>
<main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-300">
    <div class="container mx-auto px-6 py-8">
        
        <form action="<?php echo e(route('admin.donation.firter')); ?>" method="GET">
            <div class="flex gap-6">

                <div class="flex-auto">
                    <label class="text-gray-700" for="name">TANGGAL AWAL</label>
                    <input class="form-input w-full mt-2 rounded-md bg-white p-3 shadow-md" type="date" name="date_from"
                        value="<?php echo e(old('date_form') ?? request()->query('date_from')); ?>">
                    <?php $__errorArgs = ['date_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="w-full bg-red-200 shadow-sm rounded-md overflow-hidden mt-2">
                            <div class="px-4 py-2">
                                <p class="text-gray-600 text-sm"><?php echo e($message); ?></p>
                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                </div>

                <div class="flex-auto">
                    <label class="text-gray-700" for="name">TANGGAL AKHIR</label>
                    <input class="form-input w-full mt-2 rounded-md bg-white p-3 shadow-md" type="date" name="date_to"
                        value="<?php echo e(old('date_to') ?? request()->query('date_to')); ?>">
                    <?php $__errorArgs = ['date_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="w-full bg-red-200 shadow-sm rounded-md overflow-hidden mt-2">
                            <div class="px-4 py-2">
                                <p class="text-gray-600 text-sm"><?php echo e($message); ?></p>
                            </div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                </div>

                <div class="flex-1">
                    <button type="submit"
                        class="mt-8 w-full p-3 bg-gray-600 text-gray-200 rounded-md shadow-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">FILTER</button>
                </div>

            </div>
        </form>


        <?php if($donations ?? ''): ?>

            <?php if(count($donations) > 0): ?>

                <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
                    <div class="inline-block min-w-full shadow-sm rounded-lg overflow-hidden">
                        <table class="min-w-full table-auto">
                            <thead class="justify-between">
                                <tr class="bg-gray-600 w-full">
                                    <th class="px-16 py-2">
                                        <span class="text-white">NAMA DONATUR</span>
                                    </th>
                                    <th class="px-16 py-2 text-left">
                                        <span class="text-white">CAMPAIGN</span>
                                    </th>
                                    <th class="px-16 py-2 text-left">
                                        <span class="text-white">TANGGAL</span>
                                    </th>
                                    <th class="px-16 py-2 text-center">
                                        <span class="text-white">JUMLAH DONASI</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border bg-white">
                
                                        <td class="px-16 py-2 flex justify-center">
                                            <?php echo e($donation->donatur->name); ?>

                                        </td>
                                        <td class="px-16 py-2">
                                            <?php echo e($donation->campaign->title); ?>

                                        </td>
                                        <td class="px-16 py-2">
                                            <?php echo e($donation->created_at); ?>

                                        </td>
                                        <td class="px-5 py-2 text-right">
                                            <?php echo e(moneyFormat($donation->amount)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="bg-red-500 text-white text-center p-3 rounded-sm shadow-md">
                                        Data Belum Tersedia!
                                    </div>
                                <?php endif; ?>
                                <tr class="border bg-gray-600 text-white font-bold">
                                    <td colspan="3" class="px-5 py-2 justify-center">
                                        TOTAL DONASI
                                    </td>
                                    <td colspan="3" class="px-5 py-2 text-right">
                                        <?php echo e(moneyFormat($total)); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> 

            <?php endif; ?>

        <?php endif; ?>

    </div>

    

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Donation - Admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/maulayyacyber/Development/LaravelProject/backend-donasi/resources/views/admin/donation/index.blade.php ENDPATH**/ ?>